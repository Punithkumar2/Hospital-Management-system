package att.infosoft.qms.NUP_QMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NupQmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NupQmsApplication.class, args);
	}

}
